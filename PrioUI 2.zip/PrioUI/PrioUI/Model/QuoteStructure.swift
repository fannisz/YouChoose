//
//  QuoteStructure.swift
//  PrioUI
//
//  Created by Fanni Szente on 20/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

class QuoteStructure: Codable {
    
    let contents: Quotes
    
}

class Quotes: Codable {
    
    let quotes: [Quote]
    
}

class Quote: Codable {
    
    let quote: String
    
}
