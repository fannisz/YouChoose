//
//  LabelExtension.swift
//  PrioUI
//
//  Created by Fanni Szente on 14/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit

extension UILabel {
    @IBInspectable
    var rotation: Int {
        get {
            return 0
        } set {
            let radians = CGFloat(CGFloat(Double.pi) * CGFloat(newValue) / CGFloat(180.0))
            self.transform = CGAffineTransform(rotationAngle: radians)
        }
    }
}
