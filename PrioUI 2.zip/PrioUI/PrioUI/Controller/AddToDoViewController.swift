//
//  AddToDoViewController.swift
//  PrioUI
//
//  Created by Fanni Szente on 16/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit

class AddToDoViewController: UIViewController {
    
    var dataController: DataController!
    var toDo: ToDo?
    let scale = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    var urgencyValue: Float?
    var importanceValue: Float?
    
    @IBOutlet weak var toDoTextField: UITextField!
    @IBOutlet weak var urgencyPicker: UIPickerView!
    @IBOutlet weak var importancePicker: UIPickerView!
    @IBOutlet weak var quoteLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setPickerDelegates(picker: urgencyPicker)
        setPickerDelegates(picker: importancePicker)
        toDo = ToDo(context: dataController.viewContext)
        QuoteAPI.getQuote { (text, error) in
            DispatchQueue.main.async {
                self.quoteLabel.text = text
            }
        }
    }
    
    @IBAction func addToDo(_ sender: UIButton) {
        toDo?.text = self.toDoTextField.text ?? ""
        toDo?.importance = self.importanceValue ?? 1
        toDo?.urgency = self.urgencyValue ?? 1
    
        if toDo!.importance > 5.0 && toDo!.urgency > 5.0 {
            toDo?.category = 1
        } else if toDo!.importance > 5.0 && toDo!.urgency <= 5.0 {
            toDo?.category = 2
        } else if toDo!.importance > 5.0 && toDo!.urgency > 5.0 {
            toDo?.category = 3
        } else {
            toDo?.category = 4
        }
        try? dataController.viewContext.save()
        self.dismiss(animated: true, completion: nil)
    }
    
    func setPickerDelegates(picker: UIPickerView) {
        picker.delegate = self
        picker.dataSource = self
    }
    
}

extension AddToDoViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 10
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return scale[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == urgencyPicker {
            self.urgencyValue = Float(scale[row])
        } else {
            self.importanceValue = Float(scale[row])
        }
    }
    
}
