//
//  MatrixCell.swift
//  PrioUI
//
//  Created by Fanni Szente on 22/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit

class MatrixCell: UITableViewCell {
    
    @IBOutlet weak var toDoLabel: UILabel!
    @IBOutlet weak var checkBoxButton: CheckboxButton!
    
}
