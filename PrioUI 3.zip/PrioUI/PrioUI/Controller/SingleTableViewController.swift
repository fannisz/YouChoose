//
//  SingleTableViewController.swift
//  PrioUI
//
//  Created by Fanni Szente on 14/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class SingleTableViewController: UITableViewController {
    
    var dataController: DataController!
    var fetchedResultsController: NSFetchedResultsController<ToDo>!
    var blockOperation: BlockOperation?
    var indexPath: IndexPath?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        setUpFetchedResultsController()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
    }
    
    //MARK: Table View methods
    override func numberOfSections(in tableView: UITableView) -> Int {
        return fetchedResultsController.sections?.count ?? 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fetchedResultsController.sections?[section].numberOfObjects ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "toDoCell", for: indexPath) as! CheckBoxCell
        
        let toDo = fetchedResultsController.object(at: indexPath)
        cell.toDoLabel.text = toDo.text
        cell.categoryLabel.text = String(Int(toDo.category))
        
        return cell
        
    }
    
    
    @IBAction func checkToDo(_ sender: CheckboxButton) {
        
        let point = tableView.convert(sender.center, from: sender.superview!)
        let size = CGSize(width: 1, height: 1)
        let aRect = CGRect(origin: point, size: size)
        let indexPathArray = tableView.indexPathsForRows(in: aRect)
        self.indexPath = indexPathArray?.first
        
        deleteToDo(at: self.indexPath!)
        
    }
    
    func deleteToDo(at indexPath: IndexPath) {
        let deletedToDo = fetchedResultsController.object(at: indexPath)
        dataController.viewContext.delete(deletedToDo)
        try? dataController.viewContext.save()
    }
    
}

//MARK: Controller extension
extension SingleTableViewController: NSFetchedResultsControllerDelegate {
    
    func setUpFetchedResultsController() {
        let fetchRequest: NSFetchRequest<ToDo> = ToDo.fetchRequest()
        let sortDescriptor1 = NSSortDescriptor(key: "category", ascending: true)
        let sortDescriptor2 = NSSortDescriptor(key: "text", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor1, sortDescriptor2]
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self

        do {
            try fetchedResultsController.performFetch()
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        blockOperation = BlockOperation()
        tableView.beginUpdates()
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tableView.performBatchUpdates({
            self.blockOperation?.start()
        }, completion: nil)
        tableView.endUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            self.blockOperation?.addExecutionBlock {
                DispatchQueue.main.async {
                    self.tableView.insertRows(at: [newIndexPath!], with: .fade)
                }
            }
        case .delete:
            self.blockOperation?.addExecutionBlock {
                DispatchQueue.main.async {
                    self.tableView.deleteRows(at: [indexPath!], with: .fade)
                }
            }
            
        default:
            break
        }
    }

}
