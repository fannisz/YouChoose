//
//  CustomTabBar.swift
//  PrioUI
//
//  Created by Fanni Szente on 16/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit

class CustomTabBar: UITabBarController {
    
    var dataController: DataController!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! AddToDoViewController
        vc.dataController = self.dataController
    }
    
}
