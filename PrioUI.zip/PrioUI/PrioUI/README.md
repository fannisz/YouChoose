#  PrioUI: Time-management redesigned

The app is based on the famous time-management/scheduling principle, the so-called "Eisenhower-matrix". By rating the user's toDos, it helps the user to better schedule his/her day, by identifying which toDos are most important to be done, which should be scheduled, delegated or eliminated.

The app displays the toDos in two views:
1. List view: The list view orders the toDos regarding their category in an ascending order. By clicking the Checkbox, the user can mark the toDo as done which then disappears.
2. Matrix view: This view represents the toDos in the matrix imagined by Eisenhower. By using the two axis, it provides a great visualization for the toDos. By checking the checkbox, the toDo is dismissed again.

By clicking the "+" button in any of the views, the user is taken to the next screen, where he/she has the possibility to add a new toDo which includes:
- Setting a title
- Rating its urgency
- Rating its importance
After clicking the button "Let's get to work!", the view controller is dismissed and the user is taken back to the tab bar controller where he/she is able to see the new toDo in both views.

