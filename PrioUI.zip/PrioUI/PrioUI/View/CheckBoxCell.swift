//
//  CheckBoxCell.swift
//  PrioUI
//
//  Created by Fanni Szente on 18/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit

class CheckBoxCell: UITableViewCell {
    
    //MARK: Outlets for single table view
    @IBOutlet weak var toDoLabel: UILabel!
    @IBOutlet weak var checkBoxButton: CheckboxButton!
    @IBOutlet weak var categoryLabel: UILabel!
    
    //MARK: Outlets for matrix view
    @IBOutlet weak var toDoLabel1: UILabel?
    @IBOutlet weak var toDoLabel2: UILabel?
    @IBOutlet weak var toDoLabel3: UILabel?
    @IBOutlet weak var toDoLabel4: UILabel?
    
}
