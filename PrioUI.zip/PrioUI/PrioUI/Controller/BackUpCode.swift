//
//  BackUpCode.swift
//  PrioUI
//
//  Created by Fanni Szente on 17/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

//    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
//        blockOperation = BlockOperation()
//    }
//
//    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
//
//        let indexSet = IndexSet(integer: sectionIndex)
//
//        switch type {
//
//        case .insert:
//            blockOperation?.addExecutionBlock {
//                self.tableView.insertSections(indexSet, with: .fade)
//            }
//
//        case.delete:
//            DispatchQueue.main.async {
//                self.blockOperation?.addExecutionBlock {
//                    self.tableView.deleteSections(indexSet, with: .fade)
//                }
//            }
//
//        case .update:
//            blockOperation?.addExecutionBlock {
//                self.tableView.reloadSections(indexSet, with: .fade)
//            }
//
//        case .move:
//            assertionFailure()
//            break
//
//        default:
//            fatalError()
//
//        }
//    }
//
//    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
//
//        switch type {
//
//        case .insert:
//            guard let newIndexPath = newIndexPath else {
//                break
//            }
//            self.blockOperation?.addExecutionBlock {
//                DispatchQueue.main.async {
//                    self.tableView.insertRows(at: [newIndexPath], with: .fade)
//                }
//            }
//
//        case .delete:
//            guard let indexPath = indexPath else {
//                break
//            }
//            self.blockOperation?.addExecutionBlock {
//                DispatchQueue.main.async {
//                    self.tableView.deleteRows(at: [indexPath], with: .fade)
//                }
//            }
//
//        case .move:
//            guard let indexPath = indexPath, let newIndexPath = newIndexPath else {
//                break
//            }
//            self.blockOperation?.addExecutionBlock {
//                DispatchQueue.main.async {
//                    self.tableView.moveRow(at: indexPath, to: newIndexPath)
//                }
//            }
//
//        case .update:
//            guard let indexPath = indexPath else {
//                break
//            }
//            self.blockOperation?.addExecutionBlock {
//                DispatchQueue.main.async {
//                    self.tableView.reloadRows(at: [indexPath], with: .fade)
//                }
//            }
//
//        default:
//            fatalError()
//        }
//    }
//
//    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
//        self.tableView.performBatchUpdates({
//            self.blockOperation?.start()
//        }, completion: nil)
//    }
    
