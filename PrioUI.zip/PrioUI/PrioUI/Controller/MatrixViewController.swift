//
//  MatrixViewController.swift
//  PrioUI
//
//  Created by Fanni Szente on 14/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class MatrixViewController: UIViewController {
    
    @IBOutlet weak var highHighTable: UITableView!
    @IBOutlet weak var lowHighTable: UITableView!
    @IBOutlet weak var highLowTable: UITableView!
    @IBOutlet weak var lowLowTable: UITableView!
    
    var dataController: DataController!
    var fetchedResultsController1: NSFetchedResultsController<ToDo>!
    var fetchedResultsController2: NSFetchedResultsController<ToDo>!
    var fetchedResultsController3: NSFetchedResultsController<ToDo>!
    var fetchedResultsController4: NSFetchedResultsController<ToDo>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tableViews = [highHighTable, lowHighTable, highLowTable, lowLowTable]
        for tableView in tableViews {
            setupTableViews(tableView: tableView!)
        }
        fetchFirstCategory()
        fetchSecondCategory()
        fetchThirdCategory()
        fetchFourthCategory()
    }
    
    func setupTableViews(tableView: UITableView) {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(CheckBoxCell.self, forCellReuseIdentifier: "toDoCell")
    }
    
}

extension MatrixViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        switch tableView {
        case highHighTable:
            return fetchedResultsController1.sections?.count ?? 1
        case lowHighTable:
            return fetchedResultsController2.sections?.count ?? 1
        case highLowTable:
            return fetchedResultsController3.sections?.count ?? 1
        case lowLowTable:
            return fetchedResultsController4.sections?.count ?? 1
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch tableView {
        case highHighTable:
            print(fetchedResultsController1.sections?[section].numberOfObjects)
            return fetchedResultsController1.sections?[section].numberOfObjects ?? 0
        case lowHighTable:
            print(fetchedResultsController2.sections?[section].numberOfObjects)
            return fetchedResultsController2.sections?[section].numberOfObjects ?? 0
        case highLowTable:
            print(fetchedResultsController3.sections?[section].numberOfObjects)
            return fetchedResultsController3.sections?[section].numberOfObjects ?? 0
        case lowLowTable:
            print(fetchedResultsController4.sections?[section].numberOfObjects)
            return fetchedResultsController4.sections?[section].numberOfObjects ?? 0
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "toDoCell", for: indexPath) as! CheckBoxCell
        
        switch tableView {
        case highHighTable:
            let toDo = fetchedResultsController1.object(at: indexPath)
            print(toDo)
            cell.toDoLabel1?.text = toDo.text
            return cell
        case lowHighTable:
            let toDo = fetchedResultsController2.object(at: indexPath)
            cell.toDoLabel2?.text = toDo.text
            return cell
        case highLowTable:
            let toDo = fetchedResultsController3.object(at: indexPath)
            cell.toDoLabel3?.text = toDo.text
            return cell
        case lowLowTable:
            let toDo = fetchedResultsController4.object(at: indexPath)
            cell.toDoLabel4?.text = toDo.text
            return cell
        default:
            return cell
        }
        
    }
    
}

//MARK: Controller extension
extension MatrixViewController: NSFetchedResultsControllerDelegate {
    
    //MARK: Setting up the fetched results controllers
    func fetchFirstCategory() {
        let fetchRequest1: NSFetchRequest<ToDo> = ToDo.fetchRequest()
        let sortDescriptor1 = NSSortDescriptor(key: "category", ascending: true)
        let sortDescriptor2 = NSSortDescriptor(key: "text", ascending: false)
        fetchRequest1.sortDescriptors = [sortDescriptor1, sortDescriptor2]
        let filter = String(1)
        let predicate = NSPredicate(format: "category == %@", filter)
        fetchRequest1.predicate = predicate
        fetchedResultsController1 = NSFetchedResultsController(fetchRequest: fetchRequest1, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "picture")
        fetchedResultsController1.delegate = self

        do {
            try fetchedResultsController1.performFetch()
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
    }
    
    func fetchSecondCategory() {
        let fetchRequest2: NSFetchRequest<ToDo> = ToDo.fetchRequest()
        let sortDescriptor1 = NSSortDescriptor(key: "category", ascending: true)
        let sortDescriptor2 = NSSortDescriptor(key: "text", ascending: false)
        fetchRequest2.sortDescriptors = [sortDescriptor1, sortDescriptor2]
        let filter = String(2)
        let predicate = NSPredicate(format: "category == %@", filter)
        fetchRequest2.predicate = predicate
        fetchedResultsController2 = NSFetchedResultsController(fetchRequest: fetchRequest2, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "picture")
        fetchedResultsController2.delegate = self

        do {
            try fetchedResultsController2.performFetch()
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
    }
    
    func fetchThirdCategory() {
        let fetchRequest3: NSFetchRequest<ToDo> = ToDo.fetchRequest()
        let sortDescriptor1 = NSSortDescriptor(key: "category", ascending: true)
        let sortDescriptor2 = NSSortDescriptor(key: "text", ascending: false)
        fetchRequest3.sortDescriptors = [sortDescriptor1, sortDescriptor2]
        let filter = String(3)
        let predicate = NSPredicate(format: "category == %@", filter)
        fetchRequest3.predicate = predicate
        fetchedResultsController3 = NSFetchedResultsController(fetchRequest: fetchRequest3, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "picture")
        fetchedResultsController3.delegate = self

        do {
            try fetchedResultsController3.performFetch()
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
    }
    
    func fetchFourthCategory() {
        let fetchRequest4: NSFetchRequest<ToDo> = ToDo.fetchRequest()
        let sortDescriptor1 = NSSortDescriptor(key: "category", ascending: true)
        let sortDescriptor2 = NSSortDescriptor(key: "text", ascending: false)
        fetchRequest4.sortDescriptors = [sortDescriptor1, sortDescriptor2]
        let filter = String(4)
        let predicate = NSPredicate(format: "category == %@", filter)
        fetchRequest4.predicate = predicate
        fetchedResultsController4 = NSFetchedResultsController(fetchRequest: fetchRequest4, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "picture")
        fetchedResultsController4.delegate = self

        do {
            try fetchedResultsController4.performFetch()
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        highHighTable.beginUpdates()
        highLowTable.beginUpdates()
        lowHighTable.beginUpdates()
        lowLowTable.beginUpdates()
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        highHighTable.endUpdates()
        highLowTable.endUpdates()
        lowHighTable.endUpdates()
        lowLowTable.endUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            highHighTable.insertRows(at: [newIndexPath!], with: .fade)
            highLowTable.insertRows(at: [newIndexPath!], with: .fade)
            lowHighTable.insertRows(at: [newIndexPath!], with: .fade)
            lowLowTable.insertRows(at: [newIndexPath!], with: .fade)
        case .delete:
            highHighTable.deleteRows(at: [indexPath!], with: .fade)
            highLowTable.deleteRows(at: [indexPath!], with: .fade)
            lowHighTable.deleteRows(at: [indexPath!], with: .fade)
            lowLowTable.deleteRows(at: [indexPath!], with: .fade)
        default:
            break
        }
    }
    
}



