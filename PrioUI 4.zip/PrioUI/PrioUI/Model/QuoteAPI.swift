//
//  QuoteAPI.swift
//  PrioUI
//
//  Created by Fanni Szente on 20/07/2020.
//  Copyright © 2020 LBS. All rights reserved.
//

import Foundation

class QuoteAPI {
    
    enum Endpoints {
        static let url = "https://quotes.rest/qod.json?category=inspire"
        
        case getQuotes
        
        var stringValue: String {
            switch self {
            case .getQuotes:
                return Endpoints.url
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }
    
    class func getQuote(completion: @escaping (String?, Error?) -> Void) {
        var request = URLRequest(url: Endpoints.getQuotes.url)
        print(request)
        request.httpMethod = "GET"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) { (data, response, error) in
            if error != nil {
                debugPrint(error)
                completion(nil, error)
            }
            print(data)
            let decoder = JSONDecoder()
            let quoteData = try? decoder.decode(QuoteStructure.self, from: data!)
            let quotes = quoteData?.contents.quotes
            let quote = quotes?.first
            let text = quote?.quote
            print(text)
            completion(text, nil)
        }
        task.resume()
    }
    
}
